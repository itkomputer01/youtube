<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT KOMPUTER</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/bootstrap.bundle.js"></script>
    <script src="js/jquery-3.6.4.min.js"> </script>

    <style>

      .col img {height: 75px;}
    </style>
</head>

<body>
<div class="container-fluid">
   <div class="row"><div class="col-md-6"> LOGO</div> <div class="col-md-6"></div>  </div>

   <div class="row"> 
    
         <div class="col">
             <a href="" id="" id="home">Home</a>
         </div>  
         <div class="col">
             <a href="" id="sd">SD</a>
         </div>  
         <div class="col">
             <a href="" id="smp">SMP</a>
         </div>  
         <div class="col">
             <a href="" id="sma">SMA</a>
         </div>  
         <div class="col">
             <a href="" id="smk">SMK</a>
         </div>  
         <div class="col">
             <a href="" id="universitas">UNIVERSITAS</a>
         </div>  
     
    </div>

        <script>
           $(document).ready(function () {
                 $("#bannersd").show();
                 $("#bannersmp").hide();
                 $("#bannersma").hide();
                 $("#bannersmk").hide();
                 $("#banneruniversitas").hide()
             

               $("#sd").click(function (e) { 
                e.preventDefault();
                $("#bannersd").show();
                 $("#bannersmp").hide();
                 $("#bannersma").hide();
                 $("#bannersmk").hide();
                 $("#banneruniversitas").hide()
                
               });          


               $("#smp").click(function (e) { 
                e.preventDefault();
                $("#bannersd").hide();
                 $("#bannersmp").show(4000);
                 $("#bannersma").hide();
                 $("#bannersmk").hide();
                 $("#banneruniversitas").hide()
                
               });          


               $("#sma").click(function (e) { 
                e.preventDefault();
                $("#bannersd").hide();
                 $("#bannersmp").hide();
                 $("#bannersma").show(4000);
                 $("#bannersmk").hide();
                 $("#banneruniversitas").hide()
                
               });          

               
               $("#smk").click(function (e) { 
                e.preventDefault();
                $("#bannersd").hide();
                 $("#bannersmp").hide();
                 $("#bannersma").hide();
                 $("#bannersmk").show(4000);
                 $("#banneruniversitas").hide()
                
               });          

               
               $("#universitas").click(function (e) { 
                e.preventDefault();
                $("#bannersd").hide();
                 $("#bannersmp").hide();
                 $("#bannersma").hide();
                 $("#bannersmk").hide();
                 $("#banneruniversitas").show(4000);
                
               });          



           });
    </script>

            
    <div class="row"  id="bannersd"> 
      <h3>SD</h3>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""> </div>
    
    </div>

    <div class="row"  id="bannersmp"> 
      <h3>SMP</h3>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
    
    </div>
    <div class="row"  id="bannersma"> 
        <h3>SMA</h3>
      <div class="col">  <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col">  <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col">  <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col">  <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col">  <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col">  <img src="gambar/kantin.jpg" alt=""></div>
    
    </div>

    <div class="row"   id="bannersmk"> 
    <h3>SMK</h3>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""></div>
      <div class="col"> <img src="gambar/kantin.jpg" alt=""></div>
    
    </div>
    

    <div class="row" id="banneruniversitas"> 
      <h3>UNIVERSITAS</h3>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
      <div class="col"><img src="gambar/kantin.jpg" alt=""> </div>
    
    </div>


   <div class="row"> <div class="col"></div></div>


</div>

</body>
</html>