<?php
include"koneksisql_server.php";
/*
$sql = "select * from obat";
$stmt = sqlsrv_query( $conn, $sql );
if( $stmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}

while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
      echo $row['NAMAOBAT'].", ".$row['HARGAOBAT']."<br />";
}

sqlsrv_free_stmt( $stmt);
*/
$idobat="G003";
$namaobat="abc";
$hargaobat=100000;

$stmt = sqlsrv_query( $conn, "insert into obat(IDOBAT,NAMAOBAT,HARGAOBAT) 
values('$idobat','$namaobat',$hargaobat)");
if($stmt > 0)
echo"success";
else
echo"gagal";

?>