<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
@media print {
	.no-print, .no-print *
	  {
	   display:none !important;
	   }
	
	}

</style>

</head>
<body>
   
  <div class="no-print">
   <img src="images/688bg.jpg" width="100%" alt=""><p></p>
  </div> 
   <a href="" onClick="window.print()"><img src="icon/print_002.png" alt=""></a>
   <h2>Daftar Harga barang</h2>
     <table width="100%" border="1">
   
          <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>Qty</th>
          <th>Harga Jual</th>
          <th>Keterangan</th>
          <th>Gambar</th>
       </tr>
       
       <tr>
          <th>1</th>
          <th>Keyboard</th>
          <th>2</th>
          <th>50000</th>
          <th>Simbada</th>
          <th><img src="images/13goku.jpg" alt="" width="150px"></th>
       </tr>
       
   
   </table>
</body>
</html>