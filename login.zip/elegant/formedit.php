<?php
include"koneksidb.php";
$tampilberita=mysqli_query($conn,"select * from tblberita where ID=$_GET[id]");
$data=mysqli_fetch_array($tampilberita);
?>
<style>
.berita label{width:100px; float:left;}

</style>

<form class="sign-up-form form" name="send" method="post" action="prosesedit.php" enctype="multipart/form-data">

<label>&nbsp;</label> <h1>Berita</h1>
 <label class="form-label-wrapper">
        <p class="form-label">Judul</p><input type="text" class="form-input" name="judul" value="<?php echo"$data[JUDUL]" ?>"> </label>
    <input type="hidden" class="form-input" name="id" value="<?php echo"$data[ID]" ?>">    
        
 <label class="form-label-wrapper"> <select name="kategori">
                            <?php
							
							$filter=mysqli_query($conn,"select * from tblkategori");
							while($z=mysqli_fetch_array($filter))
							{
							 echo"<option value='$z[ID]'> $z[NAMAKAT]</option>";
							}
							
							 ?>

                         </select>   </label>

 <label class="form-label-wrapper">    <p class="form-label">Headline</p>
  <textarea name="headline" cols="60" rows="5"> <?php echo"$data[HEADLINE]" ?>     </textarea></label>

 <label class="form-label-wrapper">    <p class="form-label">Berita</p> 
 <textarea name="berita" id="" cols="60" rows="5">  <?php echo"$data[BERITA]" ?>  </textarea></label>

 <label class="form-label-wrapper">    <p class="form-label">Upload</p><input class="form-input" type="file" name="data"></label>
   <button class="form-btn primary-default-btn transparent-btn">Edit </button>
</form>


