<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" href="css/style.css">
</head>

<body class="body">
<div class="kanvas">
    <div class="frmlogin"> 
    <form action="proseslogin1.php" method="post" class="lgn"><p>
         <label>&nbsp;</label><img src="images/49linux.png" width="80" alt=""> <p>
         <label>Username</label> <input type="text" name="username"><p>
         <label>Password </label> <input type="password" name="password"><p>
         <label>&nbsp; </label>  <input type="submit" name="login" value="LOGIN">
    </form>     
    </div>

</div>
</body>
</html>