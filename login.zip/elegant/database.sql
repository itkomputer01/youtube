-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2022 at 12:05 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `absenpeserta`
--

-- --------------------------------------------------------

--
-- Table structure for table `menunav`
--

CREATE TABLE `menunav` (
  `LISTMENU` text NOT NULL,
  `ID` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menunav`
--

INSERT INTO `menunav` (`LISTMENU`, `ID`) VALUES
('<nav class=\"navbar navbar-expand-lg bg-dark navbar-dark py-2 py-lg-0 px-lg-5\">\r\n            <a href=\"index.php\" class=\"navbar-brand d-block d-lg-none\">\r\n                <h1 class=\"m-0 display-4 text-uppercase text-primary\">Biz<span class=\"text-white font-weight-normal\">News</span></h1>\r\n            </a>\r\n            <button type=\"button\" class=\"navbar-toggler\" data-toggle=\"collapse\" data-target=\"#navbarCollapse\">\r\n                <span class=\"navbar-toggler-icon\"></span>\r\n            </button>\r\n            <div class=\"collapse navbar-collapse justify-content-between px-0 px-lg-3\" id=\"navbarCollapse\">\r\n                <div class=\"navbar-nav mr-auto py-0\">\r\n                    <a href=\"index.php\" class=\"nav-item nav-link active\">Home</a>\r\n                    <a href=\"category.html\" class=\"nav-item nav-link\">Category</a>\r\n                    <a href=\"single.html\" class=\"nav-item nav-link\">Single News</a>\r\n                    <div class=\"nav-item dropdown\">\r\n                        <a href=\"#\" class=\"nav-link dropdown-toggle\" data-toggle=\"dropdown\">Dropdown</a>\r\n                        <div class=\"dropdown-menu rounded-0 m-0\">\r\n                            <a href=\"#\" class=\"dropdown-item\">Menu item 1</a>\r\n                            <a href=\"#\" class=\"dropdown-item\">Menu item 2</a>\r\n                            <a href=\"#\" class=\"dropdown-item\">Menu item 3</a>\r\n                        </div>\r\n                    </div>\r\n                    <a href=\"contact.html\" class=\"nav-item nav-link\">Contact</a>\r\n                </div>\r\n                <div class=\"input-group ml-auto d-none d-lg-flex\" style=\"width: 100%; max-width: 300px;\">\r\n                    <input type=\"text\" class=\"form-control border-0\" placeholder=\"Keyword\">\r\n                    <div class=\"input-group-append\">\r\n                        <button class=\"input-group-text bg-primary text-dark border-0 px-3\"><i\r\n                                class=\"fa fa-search\"></i></button>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </nav>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nis`
--
-- Error reading structure for table absenpeserta.nis: #1932 - Table &#039;absenpeserta.nis&#039; doesn&#039;t exist in engine
-- Error reading data for table absenpeserta.nis: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `absenpeserta`.`nis`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `registrasi`
--

CREATE TABLE `registrasi` (
  `ID` int(6) NOT NULL,
  `NAMA` varchar(40) NOT NULL,
  `EMAIL` varchar(55) NOT NULL,
  `TELP` varchar(16) NOT NULL,
  `USERNAME` varchar(40) NOT NULL,
  `PASSWORD` varchar(120) NOT NULL,
  `PHOTO` varchar(50) NOT NULL,
  `LEVEL` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrasi`
--

INSERT INTO `registrasi` (`ID`, `NAMA`, `EMAIL`, `TELP`, `USERNAME`, `PASSWORD`, `PHOTO`, `LEVEL`) VALUES
(15, 'tes', 'tes@yahoo.com', '1234', 'tes', '$2y$10$A05MZTi8LSWHK1ReudCPPOpec25kwYyuBP0U0zk4NwmqWAhE3z0s.', '', 'Staff');

-- --------------------------------------------------------

--
-- Table structure for table `tblberita`
--

CREATE TABLE `tblberita` (
  `ID` int(7) NOT NULL,
  `JUDUL` varchar(100) NOT NULL,
  `KATEGORI` int(5) NOT NULL,
  `HEADLINE` text NOT NULL,
  `BERITA` text NOT NULL,
  `GAMBAR` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblberita`
--

INSERT INTO `tblberita` (`ID`, `JUDUL`, `KATEGORI`, `HEADLINE`, `BERITA`, `GAMBAR`) VALUES
(6, 'ss', 1, ' s', 'ss', 'images/best.jpg'),
(7, 'hallo ', 1, ' tes 123', 'tes', 'images/hardware-komputer.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblkategori`
--

CREATE TABLE `tblkategori` (
  `ID` int(5) NOT NULL,
  `NAMAKAT` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblkategori`
--

INSERT INTO `tblkategori` (`ID`, `NAMAKAT`) VALUES
(1, 'Olahraga'),
(2, 'Iptek');

-- --------------------------------------------------------

--
-- Table structure for table `tblsos`
--

CREATE TABLE `tblsos` (
  `ID` int(4) NOT NULL,
  `JENISSOS` varchar(30) NOT NULL,
  `ALAMAT` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsos`
--

INSERT INTO `tblsos` (`ID`, `JENISSOS`, `ALAMAT`) VALUES
(1, 'fa-twitter', 'https://twitter.com/itkomputer'),
(2, 'fa-facebook-f', 'facebook.com/cucunhendayani');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menunav`
--
ALTER TABLE `menunav`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `registrasi`
--
ALTER TABLE `registrasi`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblberita`
--
ALTER TABLE `tblberita`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblkategori`
--
ALTER TABLE `tblkategori`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblsos`
--
ALTER TABLE `tblsos`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menunav`
--
ALTER TABLE `menunav`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registrasi`
--
ALTER TABLE `registrasi`
  MODIFY `ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblberita`
--
ALTER TABLE `tblberita`
  MODIFY `ID` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblkategori`
--
ALTER TABLE `tblkategori`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblsos`
--
ALTER TABLE `tblsos`
  MODIFY `ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
