  
 <div class='users-table table-wrapper'>
              <table class='posts-table'>
                <thead>
                  <tr class='users-table-info'>
                    <th>
                      <label class='users-table__checkbox ms-20'>
                        <input type='checkbox' class='check-all'>Thumbnail
                      </label>
                    </th>
                    <th>Title</th>
                    
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
  <?php              
    include"../koneksidb.php";
  
	$filter=mysqli_query($conn,"select  tblberita.ID, tblberita.JUDUL,tblberita.HEADLINE,tblberita.GAMBAR,tblkategori.NAMAKAT
from tblberita inner JOIN tblkategori on tblberita.KATEGORI=tblkategori.ID");
	
	while($z=mysqli_fetch_array($filter))
	{
    echo"       <tr>
                    <td>
                      <label class='users-table__checkbox'>
                        <input type='checkbox' class='check'>
                        <div class='categories-table-img'>
                          <picture><source srcset='../$z[GAMBAR]' type='image/webp'>
						  <img src='../$z[GAMBAR]' alt='category'></picture>
                        </div>
                      </label>
                    </td>
                    <td>
                      $z[JUDUL]
                    </td>
                    
                    <td><span class='badge-pending'>Pending</span></td>
                    <td>17.04.2021</td>
                    <td>
                      <span class='p-relative'>
                        <button class='dropdown-btn transparent-btn' type='button' title='More info'>
                          <div class='sr-only'>More info</div>
                          <i data-feather='more-horizontal' aria-hidden='true'></i>
                        </button>
                        <ul class='users-item-dropdown dropdown'>
                          <li><a href='?data=editpage&id=$z[ID]''>Edit</a></li>
                          <li><a href='##'>Quick edit</a></li>
                          <li><a href='?data=deletellpage&id=$z[ID]' 
						  onclick=\"return confirm('Are you sure you want to')\">Trash</a></li>
                        </ul>
                      </span>
                    </td>
                  </tr>";
	                }
					?>
                </tbody>
              </table>
            </div>
    
	