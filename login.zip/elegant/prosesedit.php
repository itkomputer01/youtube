<?php

include"koneksidb.php";	
$a=$_POST['judul'];

$b=$_POST['kategori'];
$c=$_POST['headline'];
$d=$_POST['berita'];
$id=$_POST['id'];
//ambil gambar atau data
$nama_gambar=$_FILES['data']['name'];
$tmp_data=$_FILES['data']['tmp_name'];
$lokasi="../images/$nama_gambar";

$lokasi2="images/$nama_gambar";

if(move_uploaded_file($tmp_data,$lokasi))
{
//echo"$a <p>$b <p> $c <p> $d";
if  (empty($a) or empty($b) or empty($c))
{
 echo"<script> alert('Data tidak valid')</script>";	
 
 echo"<meta http-equiv='refresh' content='1;url=formberita.php'>";
 
}

else
{
	$input=mysqli_query($conn,"update tblberita set judul='$a', kategori='$b', headline='$c',berita='$d' ,
	gambar='$lokasi2' where id=$id");
	if($input > 0)
	{
	echo"<script> alert('Success')</script>";
	echo"<meta http-equiv='refresh' content='1;url=index2.php?data=allpost'>";
	}
	else
	{
	echo"Input Gagal";
	}
}

}


	$input=mysqli_query($conn,"update tblberita set judul='$a', kategori='$b', headline='$c',berita='$d'  where id=$id");
	if($input > 0)
	{
	echo"<script> alert('Success')</script>";
	echo"<meta http-equiv='refresh' content='1;url=index2.php?data=allpost'>";
	}
	else
	{
	echo"Input Gagal";
	}


?>
