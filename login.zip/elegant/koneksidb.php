<?php
//script koneksi ke database
$server="localhost";
$user="root";
$pass="";
$db="absenpeserta";

$conn=mysqli_connect($server,$user,$pass,$db);


?>
