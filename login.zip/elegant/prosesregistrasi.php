<?php
include"koneksidb.php";
$a=$_POST['nama'];
$b=$_POST['email'];
$c=$_POST['telp'];
$d=$_POST['username'];


$e=password_hash($_POST['password'],PASSWORD_DEFAULT); 


if (empty($a) or empty($b) or empty($c))
{
echo"<script> alert('Data tidaka falid')</script>"	;
}
else
{
  $input=mysqli_query($conn,"insert into registrasi(NAMA,EMAIL,TELP,USERNAME,PASSWORD,LEVEL) 
  value('$a','$b','$c','$d','$e','Staff')");
  
  if ($input > 0)
{
  echo"<meta http-equiv='refresh' content='1;url=signin.php'>";	
  echo"<script> alert('Registrasi success')</script>";
}
  else
  echo"Input gagal";

}



?>