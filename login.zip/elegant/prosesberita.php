<?php

include"../koneksidb.php";	
$a=$_POST['judul'];

$b=$_POST['kategori'];
$c=$_POST['headline'];
$d=$_POST['berita'];
//ambil gambar atau data
$nama_gambar=$_FILES['data']['name'];
$tmp_data=$_FILES['data']['tmp_name'];
$lokasi="../images/$nama_gambar";

$lokasi2="images/$nama_gambar";

if(move_uploaded_file($tmp_data,$lokasi))
{
//echo"$a <p>$b <p> $c <p> $d";
if  (empty($a))
{
 echo"<script> alert('Data tidak valid')</script>";	
 
 //echo"<meta http-equiv='refresh' content='1;url=formberita.php'>";
 
}

else
{
	$input=mysqli_query($conn,"insert into tblberita(judul,kategori,headline,berita,gambar)  
	values('$a','$b','$c','$d','$lokasi2') ");
	if($input > 0)
	{
	echo"<script> alert('Success')</script>";
	echo"<meta http-equiv='refresh' content='1;url=index.php'>";
	}
	else
	{
	echo"Input Gagal";
	}
}

}
?>
