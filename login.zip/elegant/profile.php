 <div class="nav-user-wrapper">
        <button href="##" class="nav-user-btn dropdown-btn" title="My profile" type="button">
          <span class="sr-only">My profile </span>
          <span class="nav-user-img">
          <?php
		    if (!empty($_SESSION['gambar']))
			{
			echo"
            <picture><source srcset='../<?php echo $_SESSION[gambar]  ?>' type='image/webp'>
            <img src='../<?php echo $_SESSION[gambar]  ?> ' alt='User name'></picture>";
			}
			else
			{
			 echo"
            <picture><source srcset='./img/avatar/avatar-illustrated-01.webp' type='image/webp'>
            <img src='./img/avatar/avatar-illustrated-01.png' alt='User name'></picture>";
			}
			
           ?> 
          </span>
        </button>
        <ul class="users-item-dropdown nav-user-dropdown dropdown">
          <li><a href="index2.php?data=profile">
              <i data-feather="user" aria-hidden="true"></i>
              <span>Profile </span>
            </a></li>
          <li><a href="##">
              <i data-feather="settings" aria-hidden="true"></i>
              <span>Account settings</span>
            </a></li>
          <li><a class="danger" href="logout.php">
              <i data-feather="log-out" aria-hidden="true"></i>
              <span> Log out </span>
            </a></li>
        </ul>
      </div>