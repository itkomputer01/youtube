<?php
include"../koneksidb.php";
$filter=mysqli_query($conn,"select * from registrasi where email='$_SESSION[email]'");

$tampildata=mysqli_fetch_array($filter);

?>
<form class="sign-up-form form" method="post" action="prosesupdate_profile.php" enctype="multipart/form-data">

<label class="form-label-wrapper">
        <p class="form-label">Name</p> <input class="form-input" type="text" name="nama" value="<?php echo"$tampildata[NAMA]" ?>">
 
        <input class="form-input" type="hidden" name="id" value="<?php echo"$tampildata[ID]" ?>">
 </label>


        
<label class="form-label-wrapper">
        <p class="form-label">Email</p><input class="form-input" type="email" name="email"  value="<?php echo"$tampildata[EMAIL]" ?>"> </label>
<label class="form-label-wrapper">
        <p class="form-label">Telp</p> <input class="form-input" type="text" name="telp"  value="<?php echo"$tampildata[TELP]" ?>"> </label>
<label class="form-label-wrapper">
        <p class="form-label">Username</p> <input class="form-input" type="text" name="username"  value="<?php echo"$tampildata[USERNAME]" ?>"></label>
        
<label class="form-label-wrapper">
        <p class="form-label">Password</p>  <input class="form-input" type="password" name="password"></label>

<label class="form-label-wrapper">
        <p class="form-label">Photo</p>  <input class="form-input" type="file" name="data"></label>


<label> &nbsp;</label> <input type="submit" name="kirim" value="Simpan">

</form>
