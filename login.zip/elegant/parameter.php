 <?php
				if (isset($_GET['data']))
				{
				  if ($_GET['data']=="addnewpost")
				  {
				   include"formberita.php";
				  }	
				  
				  elseif ($_GET['data']=="allpost")
				  {
				   include"allpost.php";
				  }	
				  
				  elseif ($_GET['data']=="deletellpage")
				  {
				   include"../koneksidb.php";	  
				   $hapus=mysqli_query($conn,"delete from tblberita where id=$_GET[id]");
				   if($hapus > 0)
				    {
						
						echo"<meta http-equiv='refresh' content='0;url=?data=allpost'>";
					}
				  }	
				  
				  
				   elseif ($_GET['data']=="editpage")
				  {
				     include"formedit.php";
				  }	
				  
				  elseif ($_GET['data']=="profile")
				  {
				    include"registrasi.php";
				  }	
				  
				   elseif ($_GET['data']=="cari")
				  {
  				   include"../koneksidb.php";	  
				  // $caridata=mysqli_query($conn," select * from registrasi where  email='$_POST[caridata]'");
				   $caridata=mysqli_query($conn," select * from registrasi where  email like'%$_POST[caridata]%' or nama
				   like '%$_POST[caridata]%' ");
				   
				   $cek=mysqli_num_rows($caridata);
				   
				  
				   if ($cek > 0)
				   {
				     while($tampil=mysqli_fetch_array($caridata))
					 {
				      echo"$tampil[NAMA] <p> $tampil[EMAIL] <p> $tampil[USERNAME] <p>";
					 }
					 
					 
				   }
				   else
				   {
				   echo"<h1>Data tidak ditemukan</h1>";
				    }
				   
				  }	
				  
				  
				}
				
				?>