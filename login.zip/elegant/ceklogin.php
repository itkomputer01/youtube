<?php
session_start(); //aktifkan session
include"koneksidb.php";
$email=$_POST['email'];


$filter=mysqli_query($conn,"select * from registrasi where email='$email'");

$cek=mysqli_num_rows($filter);
if ($cek > 0)
{

$data=mysqli_fetch_assoc($filter);
if(password_verify($_POST['password'], $data['PASSWORD']) ) 
{
// login berhasil
$_SESSION['email']="$email";   //simpan variabel session
$_SESSION['password']="$password";
$_SESSION['gambar']="$data[PHOTO]";
$_SESSION['level']="$data[LEVEL]";

header("location:index.php");
}

else
{
echo"Login gagal";
}

}

else
{
echo"Anda belum registrasi";
}
?>